"use strict";(()=>{var c=[{id:"should-be-news",label:"This is news \u2014 the checker stayed dormant"},{id:"should-not-be-news",label:"This isn't news \u2014 it shouldn't engage"},{id:"missed-claims",label:"It missed claims it should have flagged"},{id:"wrong-claim",label:"It flagged the wrong text"},{id:"other",label:"Something else"}];var d="ugly-fact:get-report";var u="ugly-fact:send-feedback",p="ugly-fact:open-url",o="https://ugly.press/",g="https://ugly.bot/account/billing";function f(t,e,n){if(!t)return{cls:"skip",value:"Skipped"};if(e===null){if(n===void 0)return{cls:"skip",value:"Running"};let s=Math.round(n/1e3);return n>=6e4?{cls:"stop",value:`Stalled \u2014 ${String(s)}s, no reply`}:{cls:"skip",value:`Running ${String(s)}s`}}if(e.error!==null)return{cls:"stop",value:`Failed \xB7 ${e.error}`};if(e.returned===0)return{cls:"skip",value:"No claims"};if(e.painted===0)return{cls:"stop",value:`0 of ${String(e.returned)} anchored`};if(e.painted<e.returned)return{cls:"pass",value:`${String(e.painted)} of ${String(e.returned)}`};let r=e.painted;return{cls:"pass",value:`${String(r)} claim${r===1?"":"s"}`}}var h={"far-left":"#1d2a4d",left:"#2a3b6b","lean-left":"#4a5a8a",center:"#9a9082","lean-right":"#c05a4a",right:"#d6261d","far-right":"#9e1a12"};function i(t){return t.replace(/[&<>"]/g,e=>e==="&"?"&amp;":e==="<"?"&lt;":e===">"?"&gt;":"&quot;")}function S(t){return t==="signed-out"?`<div class="block">
      <div class="block-h">Sign in to continue</div>
      <div class="block-p">Claim checking is billed to your account, so the
        checker needs you signed in.</div>
      <button class="act" data-url="${o}">Sign in to ugly.press</button>
    </div>`:`<div class="block">
    <div class="block-h">Out of credit</div>
    <div class="block-p">Your ugly.bot balance is empty, so the checker cannot
      run.</div>
    <button class="act" data-url="${g}">Add funds</button>
  </div>`}function E(t){let e=t.rating;if(e===null)return`<div class="card"><div class="glyph" style="background:var(--faint)">?</div>
      <div><div class="nm">Unrated source</div>
      <div class="meta">${i(t.host)}<br>No published reliability rating.</div>
      </div></div>`;let n=h[e.bias],r=e.biasScore>=0?"+":"";return`<div class="card">
    <div class="glyph" style="background:${n}">${i(e.name.slice(0,1))}</div>
    <div>
      <div class="nm">${i(e.name)}</div>
      <div class="meta">
        <span class="pill" style="background:color-mix(in srgb, ${n} 18%, transparent);color:${n}">
          ${i(e.bias)} ${r}${String(e.biasScore)}</span>
        factuality: <b>${i(e.factuality)}</b><br>
        ${i(e.owner??"Unknown owner")}${e.country===null?"":" \xB7 "+i(e.country)}
      </div>
    </div></div>`}function R(t,e,n){let r=t.verdict.engage,s=f(r,e,n??void 0);return[["Tier 0 \xB7 page shape",r?"pass":"stop",r?"Article":"Stopped"],["Tier 1 \xB7 publisher",r?t.rating===null?"skip":"pass":"skip",r?t.rating===null?"Unrated":"Rated":"Skipped"],["Tier 2 \xB7 corpus","skip","Not in this build"],["Tier 3 \xB7 claims",s.cls,s.value]].map(([a,y,v])=>`<div class="row ${y}"><span class="k">${i(a)}</span><span class="v">${i(v)}</span></div>`).join("")}function x(){return`<div class="lab">Report a problem</div>
    <select id="fb-kind" class="fb-sel">${c.map(e=>`<option value="${e.id}">${i(e.label)}</option>`).join("")}</select>
    <textarea id="fb-note" class="fb-note" rows="2"
      placeholder="Anything else worth knowing (optional)"></textarea>
    <button id="fb-send" class="act fb-send">Send report</button>
    <div id="fb-state" class="fb-state"></div>`}function T(t){let e=t.querySelector("#fb-kind"),n=t.querySelector("#fb-note"),r=t.querySelector("#fb-send"),s=t.querySelector("#fb-state");e===null||n===null||r===null||s===null||r.addEventListener("click",()=>{r.disabled=!0,s.textContent="Sending\u2026";let l={type:u,kind:e.value,description:n.value,userAgent:navigator.userAgent,screenWidth:window.screen.width,screenHeight:window.screen.height};(async()=>{let a=await chrome.runtime.sendMessage(l);if(a?.ok===!0){s.textContent="Thanks \u2014 report sent with the page log.",s.className="fb-state ok";return}r.disabled=!1,s.className="fb-state bad",s.textContent=`Could not send: ${a?.error??"unknown error"}`})()})}function b(t){for(let e of Array.from(t.querySelectorAll("button[data-url]")))e.addEventListener("click",()=>{let n=e.getAttribute("data-url");if(n===null)return;let r={type:p,url:n};chrome.runtime.sendMessage(r),window.close()})}async function m(){let t=document.getElementById("root");if(t===null)return;let e=await chrome.runtime.sendMessage({type:d});if(e!==null&&e.status!=="ok"){t.innerHTML=S(e.status),b(t);return}let n=e?.report??null;if(n===null){t.innerHTML='<div class="why">No reading for this tab yet. Reload the page and try again.</div>';return}t.innerHTML=E(n)+`<div class="lab">${n.verdict.engage?"Status":"Dormant"}</div><div class="why">${i(n.verdict.reason)}</div><div class="lab">The gate</div>`+R(n,e?.outcome??null,e?.runningMs??null)+`<button class="act ghost" data-url="${o}">Open Ugly Press</button>`+x(),T(t),b(t),n.verdict.engage&&(e?.outcome??null)===null&&(e?.runningMs??0)<6e4&&setTimeout(()=>{let r=t.querySelector("#fb-note");r!==null&&r.value!==""||m()},1e3)}m();})();
